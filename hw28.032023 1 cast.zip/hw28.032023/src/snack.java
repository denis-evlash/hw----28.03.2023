public enum snack {
MARS, SNIKERS, TWIX, KITKAT

}
