import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//Создайте перечисление для угощений в снек-автомате (3-4 позиции).
        //Пользователь вводит номер снека. Программа должна вывести название снека, который выдал автомат.
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите номер Сладости: ");
        int numberSnace = scn.nextInt();
        if (numberSnace == 1) {
            System.out.println(snack.MARS);
        }
        if (numberSnace == 2) {
            System.out.println(snack.SNIKERS);
        }
        if (numberSnace == 3) {
            System.out.println(snack.TWIX);
        }
        if (numberSnace == 4) {
            System.out.println(snack.KITKAT);
        }


    }
}

